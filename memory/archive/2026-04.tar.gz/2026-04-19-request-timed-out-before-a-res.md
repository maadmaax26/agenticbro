# Session: 2026-04-19 02:05:24 UTC

- **Session Key**: agent:main:telegram:group:-1003751594817
- **Session ID**: 393a3312-7e2b-4009-8671-eed1b9f780f9
- **Source**: webchat

## Conversation Summary

user: Conversation info (untrusted metadata):
```json
{
  "chat_id": "telegram:-1003751594817",
  "message_id": "16246",
  "sender_id": "1087968824",
  "conversation_label": "$AGNTCBRO id:-1003751594817",
  "sender": "Group",
  "timestamp": "Sat 2026-04-18 21:47 EDT",
  "group_subject": "$AGNTCBRO",
  "is_group_chat": true
}
```

Sender (untrusted metadata):
```json
{
  "label": "Group (1087968824)",
  "id": "1087968824",
  "name": "Group",
  "username": "GroupAnonymousBot"
}
```

test
user: Conversation info (untrusted metadata):
```json
{
  "chat_id": "telegram:-1003751594817",
  "message_id": "16249",
  "sender_id": "1087968824",
  "conversation_label": "$AGNTCBRO id:-1003751594817",
  "sender": "Group",
  "timestamp": "Sat 2026-04-18 22:04 EDT",
  "group_subject": "$AGNTCBRO",
  "is_group_chat": true
}
```

Sender (untrusted metadata):
```json
{
  "label": "Group (1087968824)",
  "id": "1087968824",
  "name": "Group",
  "username": "GroupAnonymousBot"
}
```

test
