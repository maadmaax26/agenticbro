# Agenticbro Agent Model Routing Configuration
**Updated:** April 12, 2026 - 10:18 AM EDT

## Purpose
Configure agenticbro agent to minimize API usage by using local models by default and only routing to cloud/Venice models when tasks require it.

## Configuration Changes

### Primary Model
**Before:** ollama/glm-5:cloud (costly API)
**After:** ollama/granite4:3b (local, free)

### Fallback Chain
1. **ollama/granite4:3b** (default, free)
2. ollama/qwen3.5:9b (local backup)
3. ollama/gemma3:12b (local backup)
4. venice/zai-org-glm-4.7-flash (cheap cloud)
5. venice/zai-org-glm-4.7 (quality cloud)
6. ollama/glm-5:cloud (backup)
7. ollama/glm-4.7:cloud (emergency)

## Routing Strategy

### Local Model Triggers (Default)
- hello, hi, hey, help, status, thanks, thank
- "what is", "how are", "good morning", "good evening"
- community chat, welcome, FAQ
- "scan first", "ape later", community questions

### Venice Flash Triggers (Cheap Cloud)
- fetch, search, check, web
- Simple web operations: $0.13 in, $0.50 out

### Venice Primary Triggers (Quality Cloud)
- investigate, analyze, detect, verify
- scam detection, priority scan, investigation
- Complex reasoning: $0.55 in, $2.65 out

### Cost Savings
- **Input:** Local (free) vs Cloud ($0.55/1M) = 100% savings
- **Output:** Local (free) vs Cloud ($2.65/1M) = 100% savings
- **Venice Flash:** Save 76% on input ($0.13 vs $0.55)
- **Venice Flash:** Save 81% on output ($0.50 vs $2.65)

## Cost Optimization Settings
- **Max cost per day:** $1.00 USD
- **Cloud only for:** investigation, complex_analysis, web_search, web_fetch
- **Local for:** community_chat, welcome, faq, simple_queries, routing

## Configuration File
`~/.openclaw/agents/agentic-bro/models.json`

## Next Steps
Monitor daily API usage to confirm cost savings.
Expected reduction: 70-80% in API costs for agenticbro agent.

$AGNTCBRO #Solana #CostOptimization