# Scam Database Display Issues - April 12, 2026

## Problems Identified

### 1. AGNTCBRO in Scammers Table (CRITICAL)
- **Issue**: AGNTCBRO (Agentic Bro) appears in `known_scammers` table with `verification_level: "High Risk"` and `risk_score: 100`
- **Reality**: AGNTCBRO is the legitimate token and should NOT be in the scammer section
- **Location in CSV**: Line 51 of scammer-database.csv
- **Entry**: `AGNTCBRO (Agentic Bro),Solana Token,@AGNTCBRO,,Unknown,Unknown,HIGH RISK,Token Impersonation,2026-04-10,,BwaPiaK2D43zt443X6WczJ4rDEAmdCBA5MDRzZ3rQD9K,,,`
- **Action Required**: Remove this entry from the database immediately

### 2. LEGITIMATE/VERIFIED Accounts in known_scammers
- **Diana Sanchez**: Listed as `VERIFIED, PAID PROMOTER` with risk_score: 2.8 (LOW) - should be in legitimate_accounts table
- **Mania (Degen_chad119)**: Listed as `LEGITIMATE, PAID PROMOTER` with risk_score: 2.2 (LOW) - should be in legitimate_accounts table
- **Crypto_Genius09**: Listed as `RESOLVED` (AMA completed) - should be removed from active scammers

### 3. Followers Count Showing 0
- All legitimate accounts in Supabase `legitimate_accounts` table have `followers: 0`
- Need to update with correct values from CSV:
  - Diana Sanchez: 717,000 followers
  - Mania (Degen_chad119): 7,800 followers
  - Phantom Wallet: 1.2M+ followers
  - Jupiter Exchange: 500K+ followers

### 4. Risk Score Discrepancies
- Diana Sanchez shows risk_score: 90 but should be 2.8 (LOW RISK)
- Other legitimate accounts show risk_score: 50 but should be low (0-5)

## ScamDatabaseModal.tsx Analysis

### Current Filtering Logic
```typescript
// Line 620-622: Query for scammers
supabase.from('known_scammers').select('*').order('risk_score', { ascending: false }).limit(50)

// Line 623: Query for legitimate accounts
supabase.from('legitimate_accounts').select('*').order('followers', { ascending: false }).limit(20)
```

### Issue: No Filter on Scammers Query
- The query fetches ALL records from `known_scammers` table
- Does NOT filter out `LEGITIMATE`, `VERIFIED`, or `PAID PROMOTER` accounts
- This causes legitimate accounts to appear in the scammers tab

### Recommended Fix
Add filter to scammers query:
```typescript
supabase
  .from('known_scammers')
  .select('*')
  .not('verification_level', 'in', '("LEGITIMATE", "VERIFIED", "PAID PROMOTER", "RESOLVED")')
  .order('risk_score', { ascending: false })
  .limit(50)
```

## Supabase Database Structure

### Tables
1. **known_scammers** - Contains all scammer entries (including legitimate ones that shouldn't be there)
2. **legitimate_accounts** - Should contain verified legitimate accounts
3. **scan_results** - User scan results
4. **stats** - Statistics

### Connection Details
- URL: https://drvasofyghnxfxvkkwad.supabase.co
- Service role key in: /Users/efinney/.openclaw/workspace/agentic-bro/.env

## Action Plan

### Priority 1: Remove AGNTCBRO from Scammers
1. Delete AGNTCBRO entry from `known_scammers` table
2. Verify it's not in any other tables incorrectly

### Priority 2: Move Legitimate Accounts
1. Move Diana Sanchez from `known_scammers` to `legitimate_accounts`
2. Move Mania (Degen_chad119) from `known_scammers` to `legitimate_accounts`
3. Remove Crypto_Genius09 from `known_scammers` (RESOLVED)

### Priority 3: Update Followers Counts
1. Update `legitimate_accounts` table with correct followers counts
2. Sync from CSV values

### Priority 4: Fix ScamDatabaseModal.tsx
1. Add filter to exclude legitimate accounts from scammers query
2. Test filtering logic
3. Deploy updated component

## Files to Modify

1. `/Users/efinney/.openclaw/workspace/aibro/src/components/ScamDatabaseModal.tsx` - Add filtering logic
2. `/Users/efinney/.openclaw/workspace/scammer-database.csv` - Remove AGNTCBRO entry
3. Supabase database - Direct updates via SQL or admin panel

## Next Steps

1. Review and approve this plan
2. Execute database updates
3. Update frontend component
4. Test website display
5. Deploy changes