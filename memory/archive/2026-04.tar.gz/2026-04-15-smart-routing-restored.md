# Smart Routing Configuration Restored — 2026-04-15

## Status
**RESTORED** — March 31, 2026 smart routing configuration restored on April 15, 2026 at 08:20 EDT

## Architecture

```
INCOMING REQUEST → LOCAL ROUTER (granite4:3b - FREE, <1s)
                         │
         ┌───────────────┼───────────────┐
         │               │               │
    LOCAL REPLY     DELEGATE TO       NO_REPLY
    (granite4:3b)   CLOUD (glm-5)     (skip)
         │               │               │
    • Greetings     • Scam scans     • Off-topic
    • Status        • Web fetch      • Member chat
    • FAQ           • Web search     • Spam
    • Simple Q&A    • Investigation   • Not for agent
    • Memory recall • Complex tasks
```

## Configuration Changes

### Primary Model
**Before:** `ollama/glm-4.7:cloud` (cloud API)
**After:** `ollama/granite4:3b` (local, FREE)

### Fallback Chain
1. **ollama/granite4:3b** (default, free)
2. **ollama/glm-5:cloud** (cloud backup)

### Agent Routing
| Agent | Model | Role | Tasks |
|-------|-------|------|-------|
| `local-router` | `granite4:3b` | First responder | Greetings, FAQ, status, simple Q&A |
| `agentic-bro` | `glm-5:cloud` | Cloud specialist | Scam scans, web fetch, investigation |
| `main` | `granite4:3b` | Cron/fallback | Cron jobs, heartbeat |

### Telegram Binding
- **All DMs** → `local-router` (classifies and routes)
- **Agentic Bro group** → `agentic-bro` (cloud specialist)

### Files Updated
- `~/.openclaw/openclaw.json` — Primary model, routing config, bindings
- `~/.openclaw/agents/local-router/agent/config.json` — Local router config
- `~/.openclaw/agents/agentic-bro/agent/config.json` — Cloud specialist config

## Cost Impact

| Metric | Before | After | Savings |
|--------|--------|-------|---------|
| Primary model | glm-4.7:cloud (API) | granite4:3b (FREE) | ~100% |
| Local requests | 0% | 80%+ | FREE |
| Cloud requests | 100% | 20% | 80% |

## Next Steps
1. ✅ Updated openclaw.json with smart routing
2. ✅ Updated local-router config
3. ✅ Updated agentic-bro config
4. ⏳ Restart gateway to apply changes
5. ⏳ Test local routing with simple message
6. ⏳ Test cloud delegation with scan request

## Rollback
If issues arise:
1. Change `primary` model back to `ollama/glm-4.7:cloud`
2. Remove `defaultAgent: "local-router"` from bindings
3. Restart gateway

---
**Created:** 2026-04-15 08:20 EDT
**Status:** Configuration updated, needs gateway restart