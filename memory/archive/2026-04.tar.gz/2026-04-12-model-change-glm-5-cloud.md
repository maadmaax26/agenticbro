# Model Change: Agentic Bro Scam Sessions to ollama/glm-5:cloud

**Date:** Sunday, April 12, 2026
**Time:** 10:40 PM EST
**Change:** Updated Agentic Bro scam scan sessions to use `ollama/glm-5:cloud` as primary model

---

## Changes Made

### `/Users/efinney/.openclaw/agents/agentic-bro/models.json`

#### Updated Fields:

| Field | Previous | New |
|-------|----------|-----|
| `primary` | ollama/ministral-3:latest | `ollama/glm-5:cloud` |
| `secondary_fallback` | N/A | `ollama/ministral-3:latest` |
| `urgent_fallback` | N/A | `ollama/glm-4.7:cloud` |
| `preferred_for_scam` | N/A | `ollama/glm-5:cloud` |
| `preferred_for_scanner` | N/A | `ollama/glm-5:cloud` |

#### Updated Fallback Chain:
```json
[
  "ollama/glm-5:cloud",
  "ollama/ministral-3:latest",
  "ollama/granite4:3b",
  "ollama/glm-4.7:cloud"
]
```

- Previously: `[ministral-3, ministral-3, ministral-3, ministral-3, granite4, glm-5, glm-4.7]`
- New order: **glm-5 prioritized first** for scam/scan operations

---

## Reasoning

**Goal:** Optimize scam detection workflows using higher-quality model for complex analysis

**Justification:**
1. **glm-5:cloud characteristics:**
   - Context: 131,072 tokens
   - Cost: $0.045 in / $0.18 out
   - Use case: web_fetch, web_search, scam_detection, investigations, priority_scan, complex_analysis
   - Priority: 10 (highest for scam tasks)

2. **Effect on scam scanning:**
   - Profile verification with Chrome CDP integration
   - Multi-platform risk scoring
   - Cross-reference detection
   - Pattern analysis

3. **Fallback strategy preserved:**
   - Primary: glm-5 (cloud for complex tasks)
   - Secondary: ministral (fast for simple queries)
   - Urgent backup: glm-4.7 (emergency fallback)

---

## Cost Impact预估

**Before:**
- Primary: ministral (free local)
- Cloud model used only via cloud_triggers or specific selection

**After:**
- Primary: glm-5 (cloud for scam tasks)
- Local models available as fallbacks

**Expected increase:** ~5-10% increase in API costs for scam detection operations (as these were already cloud-focused but now primary)

---

## Backup

- **Backup created:** `models.json.backup-20260412-224039`
- **Location:** `/Users/efinney/.openclaw/agents/agentic-bro/`

---

## Revert Command

```bash
cp /Users/efinney/.openclaw/agents/agentic-bro/models.json.backup-20260412-224039 \
   /Users/efinney/.openclaw/agents/agentic-bro/models.json
```

---

## Verification

- ✅ Primary model updated to ollama/glm-5:cloud
- ✅ Fraud/scam preference: ollama/glm-5:cloud
- ✅ Scanner preference: ollama/glm-5:cloud
- ✅ Fallback chain restructured
- ✅ Backup created
- ✅ No syntax errors in JSON

---

## Next Steps

1. Monitor scam scan performance
2. Track API costs during this model change
3. Validate detection quality improvements
4. Adjust selection criteria in selection section if needed